//Aaron Schneidereit
//100600958
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <algorithm>
#include <ctime>
#include "bst.h"
#include "Dictionary_LL.h"
//  add any other needed include files..

int main(int argc, const char * argv[]) {

    // declare your data structures here
    BSTree myTree;
    Dict_linked_list dict1;
    Dict_linked_list dict2;
    std::string unique1 [100000];
    std::string unique2 [100000];
    int uniqueIndex1 = 0;
    int uniqueIndex2 = 0;
    int notDict1 = 0;
    int notDict2 = 0;
    int totalWords = 0;
    int wordUnique = 0;


// Here is an idea of how to get started -- You *may* want to use it..
    std::ifstream infile(argv[1]);
    std::ifstream dictionary1("dictionary.txt");
    std::ifstream dictionary2("dictionary-brit.txt");

    std::string line;
    std::string word;
    bool check;

    while(std::getline(dictionary1, line))
    {
        std::istringstream iss(line);
        while(iss >> word)
        {

            dict1.insert(word);

        }
    }

    while(std::getline(dictionary2, line))
    {
        std::istringstream iss(line);
        while(iss >> word)
        {
            dict2.insert(word);
        }
    }


    while(std::getline(infile, line))
    {
        std::istringstream iss(line);
        while(iss >> word)
        {
            word.erase(std::remove_if (word.begin(), word.end(), ispunct), word.end());
            std::transform(word.begin(), word.end(), word.begin(), ::tolower);

            totalWords++;

            check = myTree.insert(word);

            if(check == true){

                wordUnique++;

                if(!(dict1.findWord(word))){

                    notDict1++;

                    unique1[uniqueIndex1] = word;
                    uniqueIndex1++;

                }

                if(!(dict2.findWord(word))){

                    notDict2++;

                    unique2[uniqueIndex2] = word;
                    uniqueIndex2++;
                }

            }

        }
    }

    std::cout << argv[1] <<std::endl;

    std::cout << notDict1 << " : ";

    for(int i = 0; i < uniqueIndex1 ; i++){
        std::cout << unique1[i] << ", ";
    }

    std::cout << "\n";
    std::cout << "\n";

    std::cout << notDict2 << " : ";

    for(int i = 0; i < uniqueIndex1; i++){
        std::cout << unique1[i] << ", ";
    }

    std::cout << "\n";
    std::cout << "\n";

    std::cout << "Total Words: " << totalWords << std::endl;

    std::cout << "Unique words: " << wordUnique << std::endl;

    std::cout << "\n";
    std::cout << "\n";

    myTree.print_range("another", "antechamber");// INSERT YOUR OWN WORDS HERE FOR THE RANGE

    return 0;
}
