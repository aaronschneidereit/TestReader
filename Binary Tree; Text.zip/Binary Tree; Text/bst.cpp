//Aaron Schneidereit
//100600958
//  bst.cpp
//

#include "bst.h"
#include <iostream>

BSTree::BSTree()
{
    root = NULL;
}

BSTree::~BSTree(){
    destroy(root);
}

void BSTree::destroy(BSTNode* p){

    if(p == NULL){
        return;
    }
    else{
        destroy(p->left);
        destroy(p->right);
        delete p;
    }
    return;
}

BSTNode* BSTree::find(BSTNode* p, std::string word){

    if(p == NULL){
        return p;
    }

    std::cout << " here*******" << std::endl;

    if(p->data == word){
        return p;
    }

    else if(word < p->data){
        return find(p->left, word);
    }

    else{
        return find(p->right, word);
    }

}

void BSTree::increment_frequency(BSTNode *ptr){

    ptr->frequency += 1;

    return;
}

void BSTree::insert(BSTNode** p, std::string word){

    std::cout << "!!!!!!!!" <<std::endl;

    BSTNode* current = *p;
    BSTNode** recurPtr;

    if(current == NULL){
        current = new BSTNode(word);
        return;
    }

    else if(word < current->data){
        recurPtr = &(current->left);
        insert(recurPtr, word);
    }

    else if(word < current->data){
        recurPtr = &(current->right);
        insert(recurPtr, word);
    }

    else{
        increment_frequency(current);
    }
}

void BSTree::insert(std::string word){

    BSTNode* placement = find(root, word);

    if(placement != NULL){
        std::cout << "Freq " << word << std::endl;
        increment_frequency(placement);
    }
    else{
        std::cout << "adding " << word << " at address " << placement << std::endl;
        insert(&root, word);
    }

    return;
}

void BSTree::print_list(BSTNode* p, int* num){

    if(num == 0){
        return;
    }

    if(p->left != NULL){
        print_list(p->left, num);
    }

    std::cout << p->data << " : " << p->frequency << std::endl;
    num -= 1;

    if(p->right != NULL){
        print_list(p->right,num);
    }
}

void BSTree::print_list(int n){

    int* num = &n;

    print_list(root, num);

    return;
}

void BSTree::print_range(std::string s1, std::string s2, BSTNode* p){

    if(p == NULL){
        return;
    }

    if((s1.compare(p->data) < 0 || s1.compare(p->data) == 0) && (s2.compare(p->data) > 0 || s2.compare(p->data) == 0)){
        print_range(s1, s2, p->left);
        std::cout << p->data << " : " << p->frequency << std::endl;
        print_range(s1, s2, p->right);
    }

    else if(s1.compare(p->data) > 0){
        print_range(s1, s2, p->right);
    }

    else if(s2.compare(p->data) < 0){
        print_range(s1, s2, p->left);
    }

}

// and so on..