//Aaron Schneidereit
//100600958
#include "Dictionary_LL.h"
#include <iostream>

Dict_linked_list::Dict_linked_list(){

    head = nullptr;
    tail = nullptr;
    size = 0;
}

Dict_linked_list::~Dict_linked_list(){

}

int Dict_linked_list::getLength() const{

    return size;
}

bool Dict_linked_list::isEmpty() const{

    return size == 0;
}

bool Dict_linked_list::insert(const listObjType newItem){

    ListNode *newPtr = new ListNode;
    newPtr->item = newItem;

    if(isEmpty())
    {
        newPtr->next = head;
        newPtr->prev = tail;
        head = newPtr;
        tail = newPtr;
        size += 1;
        return true;
    }

    else
    {
        ListNode *current = tail;

        current->next = newPtr;
        newPtr->next = nullptr;
        newPtr->prev = current;
        tail = newPtr;

        size+=1;
        return true;

    }
}

bool Dict_linked_list::findWord(std::string word){

    ListNode* iter = head;
    int count = 0;

    while(count < getLength()){

        if(word != iter->item){

            iter = iter->next;
        }
        else{

            return true;
        }

        count++;

    }
    return false;


}





