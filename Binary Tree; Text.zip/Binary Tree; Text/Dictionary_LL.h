//Aaron Schneidereit
//100600958
#include <string>

typedef std::string listObjType;

class Dict_linked_list{

private:
    struct ListNode
    {
        listObjType item;
        ListNode *next;
        ListNode *prev;

    };

    int size;
    ListNode *head;
    ListNode *tail;

public:

    Dict_linked_list();
    ~Dict_linked_list();
    int getLength() const;
	bool insert(const listObjType newItem);
	bool isEmpty() const;
	bool findWord(std::string);

};